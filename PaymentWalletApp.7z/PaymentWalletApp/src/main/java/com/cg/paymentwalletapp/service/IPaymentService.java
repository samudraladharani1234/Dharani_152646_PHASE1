package com.cg.paymentwalletapp.service;

import com.cg.paymentwalletapp.dto.Wallet;
import com.cg.paymentwalletapp.exception.PaymentException;

public interface IPaymentService {
	public boolean createAccount(Wallet wallet);

	public double showBalance(String phNumber);

	public boolean deposit(String phNumber, double amount);

	public boolean withdraw(String phNumber, double amount);

	public boolean fundTransfer(String phSender, String phReceiver, double amount) throws PaymentException;

	public String printTransactions(String phNumber);

	public boolean validateDetails(Wallet wallet) throws PaymentException;

	public Wallet login(String id, String password) throws PaymentException;

}
